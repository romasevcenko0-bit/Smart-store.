export type Product = {
  id: number; brand: string; name: string; price: number; mem: string;
  color: string; hex: string; screen: string; cpu: string; cam: string;
  bat: string; stock: boolean; isNew: boolean; hot: boolean;
};

export const BRANDS = ["Apple", "Samsung", "Xiaomi", "Redmi", "Honor", "Google Pixel"];

export const som = (n: number): string => n.toLocaleString("ru-RU") + " сом";

type Row = [number, string, string, number, string, string, string, string, string, string, string, boolean, boolean, boolean];

const RAW: Row[] = [
  [1, "Apple", "iPhone 16 Pro", 119900, "256 ГБ", "Титан пустыни", "#b9a38a", "6.3″ OLED 120 Гц", "Apple A18 Pro", "48 + 48 + 12 Мп", "3582 мАч", true, true, true],
  [2, "Apple", "iPhone 15", 79900, "128 ГБ", "Розовый", "#e8c4c4", "6.1″ OLED", "Apple A16 Bionic", "48 + 12 Мп", "3349 мАч", true, false, true],
  [3, "Apple", "iPhone 14", 64900, "128 ГБ", "Тёмная ночь", "#2b2f3a", "6.1″ OLED", "Apple A15 Bionic", "12 + 12 Мп", "3279 мАч", true, false, false],
  [4, "Samsung", "Galaxy S25 Ultra", 109900, "256 ГБ", "Титановый серый", "#8a8f98", "6.9″ AMOLED 120 Гц", "Snapdragon 8 Elite", "200 + 50 + 10 + 50 Мп", "5000 мАч", true, true, true],
  [5, "Samsung", "Galaxy A56", 33900, "256 ГБ", "Графит", "#4b4f58", "6.7″ AMOLED 120 Гц", "Exynos 1580", "50 + 12 + 5 Мп", "5000 мАч", true, true, false],
  [6, "Samsung", "Galaxy A36", 27900, "128 ГБ", "Лаванда", "#b7a6dc", "6.7″ AMOLED", "Snapdragon 6 Gen 3", "50 + 8 + 5 Мп", "5000 мАч", true, false, true],
  [7, "Xiaomi", "Xiaomi 15", 74900, "256 ГБ", "Белый", "#e9edf2", "6.36″ AMOLED 120 Гц", "Snapdragon 8 Elite", "50 + 50 + 50 Мп", "5240 мАч", true, true, false],
  [8, "Xiaomi", "Xiaomi 14T", 49900, "256 ГБ", "Синий", "#3d5fa8", "6.67″ AMOLED 144 Гц", "Dimensity 8300 Ultra", "50 + 50 + 12 Мп", "5000 мАч", false, false, false],
  [9, "Redmi", "Redmi Note 14 Pro", 21900, "256 ГБ", "Фиолетовый", "#7a5fc9", "6.67″ AMOLED 120 Гц", "Helio G100 Ultra", "200 + 8 + 2 Мп", "5110 мАч", true, true, true],
  [10, "Redmi", "Redmi 14C", 9900, "128 ГБ", "Чёрный", "#20242c", "6.88″ IPS 120 Гц", "Helio G81 Ultra", "50 + 0.08 Мп", "5160 мАч", true, false, true],
  [11, "Honor", "Honor 400", 36900, "256 ГБ", "Зелёный", "#3f8a73", "6.55″ AMOLED 120 Гц", "Snapdragon 7 Gen 3", "200 + 12 Мп", "5300 мАч", true, true, false],
  [12, "Honor", "Honor X9c", 25900, "256 ГБ", "Бирюзовый", "#2aa6b8", "6.78″ AMOLED 120 Гц", "Snapdragon 6 Gen 1", "108 + 5 Мп", "6600 мАч", true, false, false],
  [13, "Google Pixel", "Pixel 9", 72900, "128 ГБ", "Обсидиан", "#2c3036", "6.3″ OLED 120 Гц", "Google Tensor G4", "50 + 48 Мп", "4700 мАч", true, true, false],
  [14, "Google Pixel", "Pixel 8a", 44900, "128 ГБ", "Мятный", "#a6d5c0", "6.1″ OLED 120 Гц", "Google Tensor G3", "64 + 13 Мп", "4492 мАч", false, false, false],
];

export const PRODUCTS: Product[] = RAW.map((r) => ({
  id: r[0], brand: r[1], name: r[2], price: r[3], mem: r[4], color: r[5], hex: r[6],
  screen: r[7], cpu: r[8], cam: r[9], bat: r[10], stock: r[11], isNew: r[12], hot: r[13],
}));
