import { useEffect, useMemo, useState } from "react";
import { BRANDS, PRODUCTS, som, type Product } from "./data";
import { CONFIG } from "./config";

type CartItem = { id: number; q: number };
type Line = { p: Product; q: number };

function PhoneImg({ hex, big }: { hex: string; big?: boolean }) {
  const id = "g" + hex.slice(1) + (big ? "b" : "");
  return (
    <svg viewBox="0 0 120 200" className={big ? "w-48 h-80" : "w-20 h-36"} aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={hex} />
          <stop offset="1" stopColor="#0f1b3d" stopOpacity=".55" />
        </linearGradient>
      </defs>
      <rect x="14" y="6" width="92" height="188" rx="18" fill="#101828" />
      <rect x="18" y="10" width="84" height="180" rx="15" fill={`url(#${id})`} />
      <rect x="40" y="16" width="40" height="8" rx="4" fill="#101828" opacity=".85" />
      <rect x="26" y="34" width="28" height="28" rx="8" fill="#101828" opacity=".35" />
      <circle cx="35" cy="43" r="5" fill="#fff" opacity=".7" />
      <circle cx="46" cy="53" r="5" fill="#fff" opacity=".7" />
    </svg>
  );
}

function Card({ p, onOpen, onAdd }: { p: Product; onOpen: (id: number) => void; onAdd: (id: number) => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-3 flex flex-col hover:shadow-lg transition">
      <button onClick={() => onOpen(p.id)} className="relative flex items-center justify-center bg-slate-50 rounded-xl h-44">
        <PhoneImg hex={p.hex} />
        {p.isNew && <span className="absolute top-2 left-2 text-[10px] font-bold bg-blue-600 text-white rounded-full px-2 py-0.5">НОВИНКА</span>}
      </button>
      <div className="text-xs text-slate-500 mt-2">{p.brand} · {p.mem}</div>
      <button onClick={() => onOpen(p.id)} className="text-left font-semibold leading-tight mt-0.5">{p.name}</button>
      <div className={"text-xs mt-1 " + (p.stock ? "text-emerald-600" : "text-amber-600")}>{p.stock ? "В наличии" : "Под заказ"}</div>
      <div className="mt-auto pt-2 flex items-center justify-between gap-2">
        <div className="font-bold text-blue-900">{som(p.price)}</div>
        <button onClick={() => onAdd(p.id)} className="bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-lg px-3 py-2">Купить</button>
      </div>
    </div>
  );
}

function Grid({ list, onOpen, onAdd }: { list: Product[]; onOpen: (id: number) => void; onAdd: (id: number) => void }) {
  if (!list.length) return <p className="text-slate-500 py-10 text-center">Ничего не найдено. Измените фильтры.</p>;
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
      {list.map((p) => <Card key={p.id} p={p} onOpen={onOpen} onAdd={onAdd} />)}
    </div>
  );
}

function Detail({ p, onAdd, onBack }: { p: Product; onAdd: (id: number) => void; onBack: () => void }) {
  const rows: [string, string][] = [["Бренд", p.brand], ["Память", p.mem], ["Цвет", p.color], ["Экран", p.screen], ["Процессор", p.cpu], ["Камера", p.cam], ["Аккумулятор", p.bat]];
  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <button onClick={onBack} className="text-blue-700 font-medium mb-4">← Назад в каталог</button>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-slate-50 rounded-2xl flex items-center justify-center py-8"><PhoneImg hex={p.hex} big /></div>
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold">{p.brand} {p.name}</h1>
          <div className={"mt-2 font-medium " + (p.stock ? "text-emerald-600" : "text-amber-600")}>{p.stock ? "✓ В наличии" : "Под заказ (2–5 дней)"}</div>
          <div className="text-3xl font-extrabold text-blue-900 mt-4">{som(p.price)}</div>
          <div className="flex items-center gap-2 mt-3 text-sm"><span className="w-5 h-5 rounded-full border" style={{ background: p.hex }} />{p.color}, {p.mem}</div>
          <button onClick={() => onAdd(p.id)} className="mt-5 w-full md:w-auto bg-blue-700 hover:bg-blue-800 text-white font-bold rounded-xl px-8 py-3">Купить</button>
          <h2 className="font-bold mt-8 mb-2">Характеристики</h2>
          <dl className="divide-y border rounded-xl">
            {rows.map((r) => (
              <div key={r[0]} className="flex justify-between gap-4 px-4 py-2.5 text-sm">
                <dt className="text-slate-500">{r[0]}</dt><dd className="font-medium text-right">{r[1]}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}

function CartDrawer({ items, setQty, onClose }: { items: Line[]; setQty: (id: number, q: number) => void; onClose: () => void }) {
  const [name, setName] = useState("");
  const [tel, setTel] = useState("");
  const [err, setErr] = useState("");
  const total = items.reduce((s, i) => s + i.p.price * i.q, 0);

  const send = () => {
    if (!name.trim() || tel.replace(/\D/g, "").length < 9) { setErr("Укажите имя и корректный номер телефона."); return; }
    const lines = items.map((i, k) => `${k + 1}. ${i.p.brand} ${i.p.name} (${i.p.mem}, ${i.p.color}) — ${i.q} шт. × ${som(i.p.price)} = ${som(i.p.price * i.q)}`);
    const msg = `Здравствуйте! Хочу оформить заказ в ${CONFIG.STORE}:\n\n${lines.join("\n")}\n\nИтого: ${som(total)}\n\nИмя: ${name.trim()}\nТелефон: ${tel.trim()}`;
    window.open(`https://wa.me/${CONFIG.WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40" onClick={onClose}>
      <div className="bg-white w-full max-w-md h-full flex flex-col" onClick={(e) => e.stopPropagation()} style={{ paddingTop: "env(safe-area-inset-top,0px)", paddingBottom: "env(safe-area-inset-bottom,0px)" }}>
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-bold text-lg">Корзина</h2>
          <button onClick={onClose} className="text-2xl leading-none px-2" aria-label="Закрыть">×</button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {!items.length && <p className="text-slate-500 text-center py-10">Корзина пуста</p>}
          {items.map((i) => (
            <div key={i.p.id} className="flex gap-3 items-center border rounded-xl p-2">
              <div className="bg-slate-50 rounded-lg w-14 h-16 flex items-center justify-center overflow-hidden">
                <div style={{ transform: "scale(.45)" }}><PhoneImg hex={i.p.hex} /></div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm truncate">{i.p.name}</div>
                <div className="text-xs text-slate-500">{i.p.mem}</div>
                <div className="text-sm font-bold text-blue-900">{som(i.p.price * i.q)}</div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setQty(i.p.id, i.q - 1)} className="w-8 h-8 rounded-lg border" aria-label="Меньше">−</button>
                <span className="w-6 text-center text-sm">{i.q}</span>
                <button onClick={() => setQty(i.p.id, i.q + 1)} className="w-8 h-8 rounded-lg border" aria-label="Больше">+</button>
                <button onClick={() => setQty(i.p.id, 0)} className="w-8 h-8 text-red-500" aria-label="Удалить">🗑</button>
              </div>
            </div>
          ))}
        </div>
        {items.length > 0 && (
          <div className="p-4 border-t space-y-2">
            <div className="flex justify-between font-bold text-lg"><span>Итого</span><span className="text-blue-900">{som(total)}</span></div>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ваше имя" className="w-full border rounded-lg px-3 py-2.5" />
            <input value={tel} onChange={(e) => setTel(e.target.value)} placeholder="Контактный номер, +996…" inputMode="tel" className="w-full border rounded-lg px-3 py-2.5" />
            {err && <div className="text-sm text-red-600">{err}</div>}
            <button onClick={send} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl py-3">Оформить заказ в WhatsApp</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [route, setRoute] = useState(location.hash.slice(1));
  const [cart, setCart] = useState<CartItem[]>([]);
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [brand, setBrand] = useState("");
  const [max, setMax] = useState(130000);
  const [sort, setSort] = useState("none");
  const [toast, setToast] = useState("");

  useEffect(() => {
    const f = () => setRoute(location.hash.slice(1));
    window.addEventListener("hashchange", f);
    return () => window.removeEventListener("hashchange", f);
  }, []);

  const scrollTo = (id: string) => setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }), 50);
  const goHome = (anchor?: string) => { location.hash = ""; setRoute(""); if (anchor) scrollTo(anchor); };
  const openP = (id: number) => { location.hash = "phone-" + id; window.scrollTo(0, 0); };
  const add = (id: number) => {
    setCart((c) => (c.find((i) => i.id === id) ? c.map((i) => (i.id === id ? { ...i, q: i.q + 1 } : i)) : [...c, { id, q: 1 }]));
    setToast("Добавлено в корзину");
    setTimeout(() => setToast(""), 1400);
  };
  const setQty = (id: number, qty: number) =>
    setCart((c) => (qty <= 0 ? c.filter((i) => i.id !== id) : c.map((i) => (i.id === id ? { ...i, q: qty } : i))));

  const items: Line[] = cart.flatMap((i) => {
    const p = PRODUCTS.find((x) => x.id === i.id);
    return p ? [{ p, q: i.q }] : [];
  });
  const count = cart.reduce((s, i) => s + i.q, 0);

  const list = useMemo(() => {
    let l = PRODUCTS.filter((p) => (!brand || p.brand === brand) && p.price <= max && (p.brand + " " + p.name).toLowerCase().includes(q.trim().toLowerCase()));
    if (sort === "asc") l = [...l].sort((a, b) => a.price - b.price);
    if (sort === "desc") l = [...l].sort((a, b) => b.price - a.price);
    return l;
  }, [q, brand, max, sort]);

  const cur = route.startsWith("phone-") ? PRODUCTS.find((p) => p.id === Number(route.slice(6))) : undefined;
  const pickBrand = (b: string) => { setBrand(b); scrollTo("catalog"); };

  return (
    <div>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b" style={{ paddingTop: "env(safe-area-inset-top,0px)" }}>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => goHome()} className="flex items-center gap-2 shrink-0">
            <span className="w-9 h-9 rounded-xl bg-blue-900 text-white font-black flex items-center justify-center">S</span>
            <span className="font-extrabold text-blue-900 hidden sm:block tracking-tight">SMART STORE</span>
          </button>
          <input value={q} onChange={(e) => { setQ(e.target.value); if (cur) goHome("catalog"); }} placeholder="Поиск смартфонов" className="flex-1 min-w-0 border rounded-xl px-4 py-2.5 bg-slate-50" />
          <button onClick={() => setOpen(true)} className="relative bg-blue-900 text-white rounded-xl px-4 py-2.5 font-semibold shrink-0">
            Корзина
            {count > 0 && <span className="absolute -top-2 -right-2 bg-red-500 text-xs rounded-full min-w-5 h-5 px-1 flex items-center justify-center">{count}</span>}
          </button>
        </div>
      </header>

      {cur ? (
        <Detail p={cur} onAdd={add} onBack={() => goHome("catalog")} />
      ) : (
        <main className="max-w-6xl mx-auto px-4">
          <section className="mt-5 rounded-3xl bg-gradient-to-r from-blue-900 to-blue-600 text-white p-6 md:p-10 flex items-center justify-between overflow-hidden">
            <div>
              <div className="text-blue-200 text-sm font-semibold">Выгодные предложения</div>
              <h1 className="text-2xl md:text-4xl font-extrabold mt-1 leading-tight">Смартфоны с гарантией<br />в Кыргызстане</h1>
              <p className="mt-2 text-blue-100 text-sm md:text-base">Оригинальная техника, цены в сомах, заказ через WhatsApp за минуту.</p>
              <button onClick={() => scrollTo("catalog")} className="mt-4 bg-white text-blue-900 font-bold rounded-xl px-6 py-3">Перейти в каталог</button>
            </div>
            <div className="hidden sm:block rotate-12 shrink-0"><PhoneImg hex="#7fb2ff" big /></div>
          </section>

          <section className="mt-6">
            <h2 className="font-bold text-lg mb-3">Бренды</h2>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {BRANDS.map((b) => <button key={b} onClick={() => pickBrand(b)} className="shrink-0 border rounded-xl px-5 py-3 font-semibold hover:border-blue-600 hover:text-blue-700">{b}</button>)}
            </div>
          </section>

          <section className="mt-8"><h2 className="font-bold text-xl mb-3">Популярные смартфоны</h2><Grid list={PRODUCTS.filter((p) => p.hot).slice(0, 4)} onOpen={openP} onAdd={add} /></section>
          <section className="mt-8"><h2 className="font-bold text-xl mb-3">Новинки</h2><Grid list={PRODUCTS.filter((p) => p.isNew).slice(0, 4)} onOpen={openP} onAdd={add} /></section>

          <section id="catalog" className="mt-10 scroll-mt-24">
            <h2 className="font-bold text-xl mb-3">Каталог</h2>
            <div className="grid md:grid-cols-3 gap-3 mb-4 bg-slate-50 rounded-2xl p-3">
              <select value={brand} onChange={(e) => setBrand(e.target.value)} className="border rounded-lg px-3 py-2.5 bg-white">
                <option value="">Все бренды</option>
                {BRANDS.map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
              <select value={sort} onChange={(e) => setSort(e.target.value)} className="border rounded-lg px-3 py-2.5 bg-white">
                <option value="none">Без сортировки</option>
                <option value="asc">Сначала дешевле</option>
                <option value="desc">Сначала дороже</option>
              </select>
              <label className="text-sm flex flex-col justify-center">
                Цена до: <b className="text-blue-900">{som(max)}</b>
                <input type="range" min={10000} max={130000} step={1000} value={max} onChange={(e) => setMax(Number(e.target.value))} className="w-full accent-blue-700" />
              </label>
            </div>
            <Grid list={list} onOpen={openP} onAdd={add} />
          </section>

          <section className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-3">
            {[["🛡️", "Гарантия", "До 12 месяцев"], ["🚚", "Доставка", "По Кыргызстану"], ["✅", "Оригинал", "Проверенная техника"], ["💬", "Заказ в WhatsApp", "Ответим за минуты"]].map((a) => (
              <div key={a[1]} className="border rounded-2xl p-4"><div className="text-2xl">{a[0]}</div><div className="font-bold mt-1">{a[1]}</div><div className="text-sm text-slate-500">{a[2]}</div></div>
            ))}
          </section>
        </main>
      )}

      <footer className="mt-12 text-blue-100" style={{ background: "#0b1740" }}>
        <div className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-3 gap-6 text-sm">
          <div><div className="font-extrabold text-white text-lg">SMART STORE</div><p className="mt-2">Магазин смартфонов для Кыргызстана.</p></div>
          <div><div className="font-bold text-white mb-1">Контакты</div><p>{CONFIG.PHONE_TEXT}</p><p>{CONFIG.CITY}</p><p>Ежедневно 09:00–20:00</p></div>
          <div><div className="font-bold text-white mb-1">Заказ</div><a className="underline" href={"https://wa.me/" + CONFIG.WHATSAPP} target="_blank" rel="noopener noreferrer">Написать в WhatsApp</a></div>
        </div>
        <div className="text-center text-xs text-blue-300 pb-6">© SMART STORE. Цены и наличие ориентировочные.</div>
      </footer>

      {open && <CartDrawer items={items} setQty={setQty} onClose={() => setOpen(false)} />}
      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-blue-900 text-white rounded-full px-5 py-2.5 text-sm shadow-lg">{toast}</div>}
    </div>
  );
}
