// Настройки магазина. Замените значения на свои.
export const CONFIG = {
  WHATSAPP: "996700000000", // номер магазина: 996XXXXXXXXX, без плюса и пробелов
  STORE: "SMART STORE",
  PHONE_TEXT: "+996 700 00 00 00",
  CITY: "Бишкек, Кыргызстан",
};
