# SMART STORE

Магазин смартфонов: React + TypeScript + Vite + Tailwind CSS.

- Номер WhatsApp и контакты: `src/config.ts`
- Товары и цены: `src/data.ts`
- Локальный запуск: `npm install`, затем `npm run dev`
- Сборка: `npm run build` (результат в `dist`)
- Публикация: Vercel, Framework Preset = Vite
